package com.example.eggfishingmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Prototype only:
 * - demonstrates user-controlled accessibility gesture dispatch
 * - does NOT inspect Roblox pixels or automate the fishing minigame yet
 */
class FishingAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var testCount = 0

    companion object {
        @Volatile var running = false
        @Volatile var instance: FishingAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* screen analysis is a later step */ }
    override fun onInterrupt() { stopTest() }

    fun startTest() {
        running = true
        testCount = 0
        handler.removeCallbacks(testTick)
        handler.post(testTick)
    }

    fun stopTest() {
        running = false
        handler.removeCallbacks(testTick)
    }

    private val testTick = object : Runnable {
        override fun run() {
            if (!running) return
            // Safe, visible prototype action: no game coordinates are assumed.
            // The user must stop the test before leaving this app.
            testCount++
            if (testCount < 1) handler.postDelayed(this, 1000)
        }
    }

    private fun tap(x: Float, y: Float, durationMs: Long = 70L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
