package com.example.eggfishingmacro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "계란을 훔치다 - 낚시 매크로 실험판"
            textSize = 21f
        }
        val note = TextView(this).apply {
            text = "\n현재 버전은 접근성 연결 및 수동 테스트용 시작/정지 골격입니다.\n게임 화면 인식, 느낌표 판독, 초록 구역 추적, 랜덤 탭 수 판독은 아직 연결되지 않았습니다.\n"
            textSize = 15f
        }
        val settings = Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "테스트 시작"
            setOnClickListener {
                FishingAccessibilityService.running = true
                FishingAccessibilityService.instance?.startTest()
            }
        }
        val stop = Button(this).apply {
            text = "정지"
            setOnClickListener {
                FishingAccessibilityService.running = false
                FishingAccessibilityService.instance?.stopTest()
            }
        }
        layout.addView(title)
        layout.addView(note)
        layout.addView(settings)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
